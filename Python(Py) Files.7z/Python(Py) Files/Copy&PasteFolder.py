import shutil
shutil.copytree('D:/a','D:/b/a')
#shutil.copy('D:/a/copyMe.txt','D:/b/a')   {Just to copy txt File}
