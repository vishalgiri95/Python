import subprocess

p = subprocess.Popen(r'D:\All Kind of files\file 1\demo.bat', shell=True)

p.wait()

print ('done')




