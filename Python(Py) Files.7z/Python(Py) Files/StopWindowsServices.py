import os 

import win32serviceutil

serviceName = "MySQL"

try:
    win32serviceutil.StopService(serviceName)
except:
    print('Service is already started')
