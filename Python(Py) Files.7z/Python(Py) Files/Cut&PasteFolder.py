import shutil
shutil.move('D:/a','D:/b/a')
