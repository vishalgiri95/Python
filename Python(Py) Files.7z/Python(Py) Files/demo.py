import os

#os.chdir('D:/')
FileCreate = open('sample.txt','w')
FileCreate.write('wriing some stuff in my text file\n')
FileCreate.write('This is capgemini \n')
FileCreate.close()
