import os
#spath = r"D:\check"
#print(os.listdir(spath))
def fcount(path, map = {}):
  count = 0
  
  for f in os.listdir(path):
    child = os.path.join(path, f)
    if os.path.isdir(child):
      child_count = fcount(child, map)
      count += child_count + 1 # unless include self
  map[path] = count
  return count
path = "D:\check"
map = {}
total = fcount(path, map)
print(total)

