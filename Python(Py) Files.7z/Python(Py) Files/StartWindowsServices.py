import os 

import win32serviceutil

serviceName = "MySQL"

try:
    win32serviceutil.StartService(serviceName)

except:
    print('Service is already started')



