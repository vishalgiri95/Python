import win32serviceutil

serviceName = "MySQL"

result = win32serviceutil.QueryServiceStatus(serviceName)
status = (16, 4, 7, 0, 0, 0, 0)
if result == status:
    print("Service is Started")
else:
    print("Service is Stoped")
